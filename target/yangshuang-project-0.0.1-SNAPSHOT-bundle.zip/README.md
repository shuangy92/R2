# Fast Food Restaurant Roster Management System

This is the web application for STM 2016 R&D 2


* Some Tips *
You can first login as a user. Set up your schedule. And then login as the Admin, and set up a roster.

The account of Admin is "admin@gmail.com" with password "admin".

As an Admin, you can create new employees.

When you set up a roster or schedule, don't press 'tab' key to change field, or the time you input may not be successfully parsed.

The check in function has not been fully implemented yet.