package com.worksap.stm2016.enums;

public enum UserStatus {
    TRAINEE, TRAINER, NORMAL;
}