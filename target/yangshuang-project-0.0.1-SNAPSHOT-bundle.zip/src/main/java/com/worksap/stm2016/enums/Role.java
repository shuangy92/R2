package com.worksap.stm2016.enums;

public enum Role {
    ADMIN, MANAGER, WAITER, CASHER, COOK;
}
