package com.worksap.stm2016.enums;

public enum Role {
    ADMIN, //HR
    MANAGER, EMPLOYEE, APPLICANT
}
