package com.worksap.stm2016.enums;

public enum RosterPlan {
    COST, QUAILITY, AVAILABILITY;
}