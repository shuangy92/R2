package com.worksap.stm2016.enums;

public enum UserIdType {
    NIN, // national identification number
    PPN, // passport number
    DLN, // driver's license number
}