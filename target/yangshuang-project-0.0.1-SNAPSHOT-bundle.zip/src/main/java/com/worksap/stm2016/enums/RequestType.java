package com.worksap.stm2016.enums;

/**
 * Created by Shuang on 4/18/2016.
 */
public enum RequestType {
    LEAVE, RESIGNATION, OTHER;
}
