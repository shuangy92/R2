package com.worksap.stm2016.enums;

public enum PayRate {
    HOURLY, DAILY, WEEKLY, MONTHLY
}
