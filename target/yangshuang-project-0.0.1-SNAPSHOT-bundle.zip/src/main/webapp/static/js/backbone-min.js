(function (t) {
    var e = typeof self == "object" && self.self === self && self || typeof global == "object" && global.global === global && global;
    if (typeof define === "function" && define.amd) {
        define(["underscore", "jquery", "exports"], function (i, r, n) {
            e.Backbone = t(e, n, i, r)
        })
    } else if (typeof exports !== "undefined") {
        var i = require("underscore"), r;
        try {
            r = require("jquery")
        } catch (n) {
        }
        t(e, exports, i, r)
    } else {
        e.Backbone = t(e, {}, e._, e.jQuery || e.Zepto || e.ender || e.$)
    }
})(function (t, e, i, r) {
    var n = t.Backbone;
    var s = Array.prototype.slice;
    e.VERSION = "1.3.3";
    e.$ = r;
    e.noConflict = function () {
        t.Backbone = n;
        return this
    };
    e.emulateHTTP = false;
    e.emulateJSON = false;
    var a = function (t, e, r) {
        switch (t) {
            case 1:
                return function () {
                    return i[e](this[r])
                };
            case 2:
                return function (t) {
                    return i[e](this[r], t)
                };
            case 3:
                return function (t, n) {
                    return i[e](this[r], o(t, this), n)
                };
            case 4:
                return function (t, n, s) {
                    return i[e](this[r], o(t, this), n, s)
                };
            default:
                return function () {
                    var t = s.call(arguments);
                    t.unshift(this[r]);
                    return i[e].apply(i, t)
                }
        }
    };
    var h = function (t, e, r) {
        i.each(e, function (e, n) {
            if (i[n])t.prototype[n] = a(e, n, r)
        })
    };
    var o = function (t, e) {
        if (i.isFunction(t))return t;
        if (i.isObject(t) && !e._isModel(t))return l(t);
        if (i.isString(t))return function (e) {
            return e.get(t)
        };
        return t
    };
    var l = function (t) {
        var e = i.matches(t);
        return function (t) {
            return e(t.attributes)
        }
    };
    var u = e.Events = {};
    var c = /\s+/;
    var f = function (t, e, r, n, s) {
        var a = 0, h;
        if (r && typeof r === "object") {
            if (n !== void 0 && "context" in s && s.context === void 0)s.context = n;
            for (h = i.keys(r); a < h.length; a++) {
                e = f(t, e, h[a], r[h[a]], s)
            }
        } else if (r && c.test(r)) {
            for (h = r.split(c); a < h.length; a++) {
                e = t(e, h[a], n, s)
            }
        } else {
            e = t(e, r, n, s)
        }
        return e
    };
    u.on = function (t, e, i) {
        return d(this, t, e, i)
    };
    var d = function (t, e, i, r, n) {
        t._events = f(v, t._events || {}, e, i, {context: r, ctx: t, listening: n});
        if (n) {
            var s = t._listeners || (t._listeners = {});
            s[n.id] = n
        }
        return t
    };
    u.listenTo = function (t, e, r) {
        if (!t)return this;
        var n = t._listenId || (t._listenId = i.uniqueId("l"));
        var s = this._listeningTo || (this._listeningTo = {});
        var a = s[n];
        if (!a) {
            var h = this._listenId || (this._listenId = i.uniqueId("l"));
            a = s[n] = {obj: t, objId: n, id: h, listeningTo: s, count: 0}
        }
        d(t, e, r, this, a);
        return this
    };
    var v = function (t, e, i, r) {
        if (i) {
            var n = t[e] || (t[e] = []);
            var s = r.context, a = r.ctx, h = r.listening;
            if (h)h.count++;
            n.push({callback: i, context: s, ctx: s || a, listening: h})
        }
        return t
    };
    u.off = function (t, e, i) {
        if (!this._events)return this;
        this._events = f(g, this._events, t, e, {context: i, listeners: this._listeners});
        return this
    };
    u.stopListening = function (t, e, r) {
        var n = this._listeningTo;
        if (!n)return this;
        var s = t ? [t._listenId] : i.keys(n);
        for (var a = 0; a < s.length; a++) {
            var h = n[s[a]];
            if (!h)break;
            h.obj.off(e, r, this)
        }
        return this
    };
    var g = function (t, e, r, n) {
        if (!t)return;
        var s = 0, a;
        var h = n.context, o = n.listeners;
        if (!e && !r && !h) {
            var l = i.keys(o);
            for (; s < l.length; s++) {
                a = o[l[s]];
                delete o[a.id];
                delete a.listeningTo[a.objId]
            }
            return
        }
        var u = e ? [e] : i.keys(t);
        for (; s < u.length; s++) {
            e = u[s];
            var c = t[e];
            if (!c)break;
            var f = [];
            for (var d = 0; d < c.length; d++) {
                var v = c[d];
                if (r && r !== v.callback && r !== v.callback._callback || h && h !== v.context) {
                    f.push(v)
                } else {
                    a = v.listening;
                    if (a && --a.count === 0) {
                        delete o[a.id];
                        delete a.listeningTo[a.objId]
                    }
                }
            }
            if (f.length) {
                t[e] = f
            } else {
                delete t[e]
            }
        }
        return t
    };
    u.once = function (t, e, r) {
        var n = f(p, {}, t, e, i.bind(this.off, this));
        if (typeof t === "string" && r == null)e = void 0;
        return this.on(n, e, r)
    };
    u.listenToOnce = function (t, e, r) {
        var n = f(p, {}, e, r, i.bind(this.stopListening, this, t));
        return this.listenTo(t, n)
    };
    var p = function (t, e, r, n) {
        if (r) {
            var s = t[e] = i.once(function () {
                n(e, s);
                r.apply(this, arguments)
            });
            s._callback = r
        }
        return t
    };
    u.trigger = function (t) {
        if (!this._events)return this;
        var e = Math.max(0, arguments.length - 1);
        var i = Array(e);
        for (var r = 0; r < e; r++)i[r] = arguments[r + 1];
        f(m, this._events, t, void 0, i);
        return this
    };
    var m = function (t, e, i, r) {
        if (t) {
            var n = t[e];
            var s = t.all;
            if (n && s)s = s.slice();
            if (n)_(n, r);
            if (s)_(s, [e].concat(r))
        }
        return t
    };
    var _ = function (t, e) {
        var i, r = -1, n = t.length, s = e[0], a = e[1], h = e[2];
        switch (e.length) {
            case 0:
                while (++r < n)(i = t[r]).callback.call(i.ctx);
                return;
            case 1:
                while (++r < n)(i = t[r]).callback.call(i.ctx, s);
                return;
            case 2:
                while (++r < n)(i = t[r]).callback.call(i.ctx, s, a);
                return;
            case 3:
                while (++r < n)(i = t[r]).callback.call(i.ctx, s, a, h);
                return;
            default:
                while (++r < n)(i = t[r]).callback.apply(i.ctx, e);
                return
        }
    };
    u.bind = u.on;
    u.unbind = u.off;
    i.extend(e, u);
    var y = e.Model = function (t, e) {
        var r = t || {};
        e || (e = {});
        this.cid = i.uniqueId(this.cidPrefix);
        this.attributes = {};
        if (e.collection)this.collection = e.collection;
        if (e.parse)r = this.parse(r, e) || {};
        var n = i.result(this, "defaults");
        r = i.defaults(i.extend({}, n, r), n);
        this.set(r, e);
        this.changed = {};
        this.initialize.apply(this, arguments)
    };
    i.extend(y.prototype, u, {
        changed: null,
        validationError: null,
        idAttribute: "id",
        cidPrefix: "c",
        initialize: function () {
        },
        toJSON: function (t) {
            return i.clone(this.attributes)
        },
        sync: function () {
            return e.sync.apply(this, arguments)
        },
        get: function (t) {
            return this.attributes[t]
        },
        escape: function (t) {
            return i.escape(this.get(t))
        },
        has: function (t) {
            return this.get(t) != null
        },
        matches: function (t) {
            return !!i.iteratee(t, this)(this.attributes)
        },
        set: function (t, e, r) {
            if (t == null)return this;
            var n;
            if (typeof t === "object") {
                n = t;
                r = e
            } else {
                (n = {})[t] = e
            }
            r || (r = {});
            if (!this._validate(n, r))return false;
            var s = r.unset;
            var a = r.silent;
            var h = [];
            var o = this._changing;
            this._changing = true;
            if (!o) {
                this._previousAttributes = i.clone(this.attributes);
                this.changed = {}
            }
            var l = this.attributes;
            var u = this.changed;
            var c = this._previousAttributes;
            for (var f in n) {
                e = n[f];
                if (!i.isEqual(l[f], e))h.push(f);
                if (!i.isEqual(c[f], e)) {
                    u[f] = e
                } else {
                    delete u[f]
                }
                s ? delete l[f] : l[f] = e
            }
            if (this.idAttribute in n)this.id = this.get(this.idAttribute);
            if (!a) {
                if (h.length)this._pending = r;
                for (var d = 0; d < h.length; d++) {
                    this.trigger("change:" + h[d], this, l[h[d]], r)
                }
            }
            if (o)return this;
            if (!a) {
                while (this._pending) {
                    r = this._pending;
                    this._pending = false;
                    this.trigger("change", this, r)
                }
            }
            this._pending = false;
            this._changing = false;
            return this
        },
        unset: function (t, e) {
            return this.set(t, void 0, i.extend({}, e, {unset: true}))
        },
        clear: function (t) {
            var e = {};
            for (var r in this.attributes)e[r] = void 0;
            return this.set(e, i.extend({}, t, {unset: true}))
        },
        hasChanged: function (t) {
            if (t == null)return !i.isEmpty(this.changed);
            return i.has(this.changed, t)
        },
        changedAttributes: function (t) {
            if (!t)return this.hasChanged() ? i.clone(this.changed) : false;
            var e = this._changing ? this._previousAttributes : this.attributes;
            var r = {};
            for (var n in t) {
                var s = t[n];
                if (i.isEqual(e[n], s))continue;
                r[n] = s
            }
            return i.size(r) ? r : false
        },
        previous: function (t) {
            if (t == null || !this._previousAttributes)return null;
            return this._previousAttributes[t]
        },
        previousAttributes: function () {
            return i.clone(this._previousAttributes)
        },
        fetch: function (t) {
            t = i.extend({parse: true}, t);
            var e = this;
            var r = t.success;
            t.success = function (i) {
                var n = t.parse ? e.parse(i, t) : i;
                if (!e.set(n, t))return false;
                if (r)r.call(t.context, e, i, t);
                e.trigger("sync", e, i, t)
            };
            B(this, t);
            return this.sync("read", this, t)
        },
        save: function (t, e, r) {
            var n;
            if (t == null || typeof t === "object") {
                n = t;
                r = e
            } else {
                (n = {})[t] = e
            }
            r = i.extend({validate: true, parse: true}, r);
            var s = r.wait;
            if (n && !s) {
                if (!this.set(n, r))return false
            } else if (!this._validate(n, r)) {
                return false
            }
            var a = this;
            var h = r.success;
            var o = this.attributes;
            r.success = function (t) {
                a.attributes = o;
                var e = r.parse ? a.parse(t, r) : t;
                if (s)e = i.extend({}, n, e);
                if (e && !a.set(e, r))return false;
                if (h)h.call(r.context, a, t, r);
                a.trigger("sync", a, t, r)
            };
            B(this, r);
            if (n && s)this.attributes = i.extend({}, o, n);
            var l = this.isNew() ? "create" : r.patch ? "patch" : "update";
            if (l === "patch" && !r.attrs)r.attrs = n;
            var u = this.sync(l, this, r);
            this.attributes = o;
            return u
        },
        destroy: function (t) {
            t = t ? i.clone(t) : {};
            var e = this;
            var r = t.success;
            var n = t.wait;
            var s = function () {
                e.stopListening();
                e.trigger("destroy", e, e.collection, t)
            };
            t.success = function (i) {
                if (n)s();
                if (r)r.call(t.context, e, i, t);
                if (!e.isNew())e.trigger("sync", e, i, t)
            };
            var a = false;
            if (this.isNew()) {
                i.defer(t.success)
            } else {
                B(this, t);
                a = this.sync("delete", this, t)
            }
            if (!n)s();
            return a
        },
        url: function () {
            var t = i.result(this, "urlRoot") || i.result(this.collection, "url") || F();
            if (this.isNew())return t;
            var e = this.get(this.idAttribute);
            return t.replace(/[^\/]$/, "$&/") + encodeURIComponent(e)
        },
        parse: function (t, e) {
            return t
        },
        clone: function () {
            return new this.constructor(this.attributes)
        },
        isNew: function () {
            return !this.has(this.idAttribute)
        },
        isValid: function (t) {
            return this._validate({}, i.extend({}, t, {validate: true}))
        },
        _validate: function (t, e) {
            if (!e.validate || !this.validate)return true;
            t = i.extend({}, this.attributes, t);
            var r = this.validationError = this.validate(t, e) || null;
            if (!r)return true;
            this.trigger("invalid", this, r, i.extend(e, {validationError: r}));
            return false
        }
    });
    var b = {keys: 1, values: 1, pairs: 1, invert: 1, pick: 0, omit: 0, chain: 1, isEmpty: 1};
    h(y, b, "attributes");
    var x = e.Collection = function (t, e) {
        e || (e = {});
        if (e.model)this.model = e.model;
        if (e.comparator !== void 0)this.comparator = e.comparator;
        this._reset();
        this.initialize.apply(this, arguments);
        if (t)this.reset(t, i.extend({silent: true}, e))
    };
    var w = {add: true, remove: true, merge: true};
    var E = {add: true, remove: false};
    var I = function (t, e, i) {
        i = Math.min(Math.max(i, 0), t.length);
        var r = Array(t.length - i);
        var n = e.length;
        var s;
        for (s = 0; s < r.length; s++)r[s] = t[s + i];
        for (s = 0; s < n; s++)t[s + i] = e[s];
        for (s = 0; s < r.length; s++)t[s + n + i] = r[s]
    };
    i.extend(x.prototype, u, {
        model: y, initialize: function () {
        }, toJSON: function (t) {
            return this.map(function (e) {
                return e.toJSON(t)
            })
        }, sync: function () {
            return e.sync.apply(this, arguments)
        }, add: function (t, e) {
            return this.set(t, i.extend({merge: false}, e, E))
        }, remove: function (t, e) {
            e = i.extend({}, e);
            var r = !i.isArray(t);
            t = r ? [t] : t.slice();
            var n = this._removeModels(t, e);
            if (!e.silent && n.length) {
                e.changes = {added: [], merged: [], removed: n};
                this.trigger("update", this, e)
            }
            return r ? n[0] : n
        }, set: function (t, e) {
            if (t == null)return;
            e = i.extend({}, w, e);
            if (e.parse && !this._isModel(t)) {
                t = this.parse(t, e) || []
            }
            var r = !i.isArray(t);
            t = r ? [t] : t.slice();
            var n = e.at;
            if (n != null)n = +n;
            if (n > this.length)n = this.length;
            if (n < 0)n += this.length + 1;
            var s = [];
            var a = [];
            var h = [];
            var o = [];
            var l = {};
            var u = e.add;
            var c = e.merge;
            var f = e.remove;
            var d = false;
            var v = this.comparator && n == null && e.sort !== false;
            var g = i.isString(this.comparator) ? this.comparator : null;
            var p, m;
            for (m = 0; m < t.length; m++) {
                p = t[m];
                var _ = this.get(p);
                if (_) {
                    if (c && p !== _) {
                        var y = this._isModel(p) ? p.attributes : p;
                        if (e.parse)y = _.parse(y, e);
                        _.set(y, e);
                        h.push(_);
                        if (v && !d)d = _.hasChanged(g)
                    }
                    if (!l[_.cid]) {
                        l[_.cid] = true;
                        s.push(_)
                    }
                    t[m] = _
                } else if (u) {
                    p = t[m] = this._prepareModel(p, e);
                    if (p) {
                        a.push(p);
                        this._addReference(p, e);
                        l[p.cid] = true;
                        s.push(p)
                    }
                }
            }
            if (f) {
                for (m = 0; m < this.length; m++) {
                    p = this.models[m];
                    if (!l[p.cid])o.push(p)
                }
                if (o.length)this._removeModels(o, e)
            }
            var b = false;
            var x = !v && u && f;
            if (s.length && x) {
                b = this.length !== s.length || i.some(this.models, function (t, e) {
                        return t !== s[e]
                    });
                this.models.length = 0;
                I(this.models, s, 0);
                this.length = this.models.length
            } else if (a.length) {
                if (v)d = true;
                I(this.models, a, n == null ? this.length : n);
                this.length = this.models.length
            }
            if (d)this.sort({silent: true});
            if (!e.silent) {
                for (m = 0; m < a.length; m++) {
                    if (n != null)e.index = n + m;
                    p = a[m];
                    p.trigger("add", p, this, e)
                }
                if (d || b)this.trigger("sort", this, e);
                if (a.length || o.length || h.length) {
                    e.changes = {added: a, removed: o, merged: h};
                    this.trigger("update", this, e)
                }
            }
            return r ? t[0] : t
        }, reset: function (t, e) {
            e = e ? i.clone(e) : {};
            for (var r = 0; r < this.models.length; r++) {
                this._removeReference(this.models[r], e)
            }
            e.previousModels = this.models;
            this._reset();
            t = this.add(t, i.extend({silent: true}, e));
            if (!e.silent)this.trigger("reset", this, e);
            return t
        }, push: function (t, e) {
            return this.add(t, i.extend({at: this.length}, e))
        }, pop: function (t) {
            var e = this.at(this.length - 1);
            return this.remove(e, t)
        }, unshift: function (t, e) {
            return this.add(t, i.extend({at: 0}, e))
        }, shift: function (t) {
            var e = this.at(0);
            return this.remove(e, t)
        }, slice: function () {
            return s.apply(this.models, arguments)
        }, get: function (t) {
            if (t == null)return void 0;
            return this._byId[t] || this._byId[this.modelId(t.attributes || t)] || t.cid && this._byId[t.cid]
        }, has: function (t) {
            return this.get(t) != null
        }, at: function (t) {
            if (t < 0)t += this.length;
            return this.models[t]
        }, where: function (t, e) {
            return this[e ? "find" : "filter"](t)
        }, findWhere: function (t) {
            return this.where(t, true)
        }, sort: function (t) {
            var e = this.comparator;
            if (!e)throw new Error("Cannot sort a set without a comparator");
            t || (t = {});
            var r = e.length;
            if (i.isFunction(e))e = i.bind(e, this);
            if (r === 1 || i.isString(e)) {
                this.models = this.sortBy(e)
            } else {
                this.models.sort(e)
            }
            if (!t.silent)this.trigger("sort", this, t);
            return this
        }, pluck: function (t) {
            return this.map(t + "")
        }, fetch: function (t) {
            t = i.extend({parse: true}, t);
            var e = t.success;
            var r = this;
            t.success = function (i) {
                var n = t.reset ? "reset" : "set";
                r[n](i, t);
                if (e)e.call(t.context, r, i, t);
                r.trigger("sync", r, i, t)
            };
            B(this, t);
            return this.sync("read", this, t)
        }, create: function (t, e) {
            e = e ? i.clone(e) : {};
            var r = e.wait;
            t = this._prepareModel(t, e);
            if (!t)return false;
            if (!r)this.add(t, e);
            var n = this;
            var s = e.success;
            e.success = function (t, e, i) {
                if (r)n.add(t, i);
                if (s)s.call(i.context, t, e, i)
            };
            t.save(null, e);
            return t
        }, parse: function (t, e) {
            return t
        }, clone: function () {
            return new this.constructor(this.models, {model: this.model, comparator: this.comparator})
        }, modelId: function (t) {
            return t[this.model.prototype.idAttribute || "id"]
        }, _reset: function () {
            this.length = 0;
            this.models = [];
            this._byId = {}
        }, _prepareModel: function (t, e) {
            if (this._isModel(t)) {
                if (!t.collection)t.collection = this;
                return t
            }
            e = e ? i.clone(e) : {};
            e.collection = this;
            var r = new this.model(t, e);
            if (!r.validationError)return r;
            this.trigger("invalid", this, r.validationError, e);
            return false
        }, _removeModels: function (t, e) {
            var i = [];
            for (var r = 0; r < t.length; r++) {
                var n = this.get(t[r]);
                if (!n)continue;
                var s = this.indexOf(n);
                this.models.splice(s, 1);
                this.length--;
                delete this._byId[n.cid];
                var a = this.modelId(n.attributes);
                if (a != null)delete this._byId[a];
                if (!e.silent) {
                    e.index = s;
                    n.trigger("remove", n, this, e)
                }
                i.push(n);
                this._removeReference(n, e)
            }
            return i
        }, _isModel: function (t) {
            return t instanceof y
        }, _addReference: function (t, e) {
            this._byId[t.cid] = t;
            var i = this.modelId(t.attributes);
            if (i != null)this._byId[i] = t;
            t.on("all", this._onModelEvent, this)
        }, _removeReference: function (t, e) {
            delete this._byId[t.cid];
            var i = this.modelId(t.attributes);
            if (i != null)delete this._byId[i];
            if (this === t.collection)delete t.collection;
            t.off("all", this._onModelEvent, this)
        }, _onModelEvent: function (t, e, i, r) {
            if (e) {
                if ((t === "add" || t === "remove") && i !== this)return;
                if (t === "destroy")this.remove(e, r);
                if (t === "change") {
                    var n = this.modelId(e.previousAttributes());
                    var s = this.modelId(e.attributes);
                    if (n !== s) {
                        if (n != null)delete this._byId[n];
                        if (s != null)this._byId[s] = e
                    }
                }
            }
            this.trigger.apply(this, arguments)
        }
    });
    var S = {
        forEach: 3,
        each: 3,
        map: 3,
        collect: 3,
        reduce: 0,
        foldl: 0,
        inject: 0,
        reduceRight: 0,
        foldr: 0,
        find: 3,
        detect: 3,
        filter: 3,
        select: 3,
        reject: 3,
        every: 3,
        all: 3,
        some: 3,
        any: 3,
        include: 3,
        includes: 3,
        contains: 3,
        invoke: 0,
        max: 3,
        min: 3,
        toArray: 1,
        size: 1,
        first: 3,
        head: 3,
        take: 3,
        initial: 3,
        rest: 3,
        tail: 3,
        drop: 3,
        last: 3,
        without: 0,
        difference: 0,
        indexOf: 3,
        shuffle: 1,
        lastIndexOf: 3,
        isEmpty: 1,
        chain: 1,
        sample: 3,
        partition: 3,
        groupBy: 3,
        countBy: 3,
        sortBy: 3,
        indexBy: 3,
        findIndex: 3,
        findLastIndex: 3
    };
    h(x, S, "models");
    var k = e.View = function (t) {
        this.cid = i.uniqueId("view");
        i.extend(this, i.pick(t, P));
        this._ensureElement();
        this.initialize.apply(this, arguments)
    };
    var T = /^(\S+)\s*(.*)$/;
    var P = ["model", "collection", "el", "id", "attributes", "className", "tagName", "events"];
    i.extend(k.prototype, u, {
        tagName: "div", $: function (t) {
            return this.$el.find(t)
        }, initialize: function () {
        }, render: function () {
            return this
        }, remove: function () {
            this._removeElement();
            this.stopListening();
            return this
        }, _removeElement: function () {
            this.$el.remove()
        }, setElement: function (t) {
            this.undelegateEvents();
            this._setElement(t);
            this.delegateEvents();
            return this
        }, _setElement: function (t) {
            this.$el = t instanceof e.$ ? t : e.$(t);
            this.el = this.$el[0]
        }, delegateEvents: function (t) {
            t || (t = i.result(this, "events"));
            if (!t)return this;
            this.undelegateEvents();
            for (var e in t) {
                var r = t[e];
                if (!i.isFunction(r))r = this[r];
                if (!r)continue;
                var n = e.match(T);
                this.delegate(n[1], n[2], i.bind(r, this))
            }
            return this
        }, delegate: function (t, e, i) {
            this.$el.on(t + ".delegateEvents" + this.cid, e, i);
            return this
        }, undelegateEvents: function () {
            if (this.$el)this.$el.off(".delegateEvents" + this.cid);
            return this
        }, undelegate: function (t, e, i) {
            this.$el.off(t + ".delegateEvents" + this.cid, e, i);
            return this
        }, _createElement: function (t) {
            return document.createElement(t)
        }, _ensureElement: function () {
            if (!this.el) {
                var t = i.extend({}, i.result(this, "attributes"));
                if (this.id)t.id = i.result(this, "id");
                if (this.className)t["class"] = i.result(this, "className");
                this.setElement(this._createElement(i.result(this, "tagName")));
                this._setAttributes(t)
            } else {
                this.setElement(i.result(this, "el"))
            }
        }, _setAttributes: function (t) {
            this.$el.attr(t)
        }
    });
    e.sync = function (t, r, n) {
        var s = H[t];
        i.defaults(n || (n = {}), {emulateHTTP: e.emulateHTTP, emulateJSON: e.emulateJSON});
        var a = {type: s, dataType: "json"};
        if (!n.url) {
            a.url = i.result(r, "url") || F()
        }
        if (n.data == null && r && (t === "create" || t === "update" || t === "patch")) {
            a.contentType = "application/json";
            a.data = JSON.stringify(n.attrs || r.toJSON(n))
        }
        if (n.emulateJSON) {
            a.contentType = "application/x-www-form-urlencoded";
            a.data = a.data ? {model: a.data} : {}
        }
        if (n.emulateHTTP && (s === "PUT" || s === "DELETE" || s === "PATCH")) {
            a.type = "POST";
            if (n.emulateJSON)a.data._method = s;
            var h = n.beforeSend;
            n.beforeSend = function (t) {
                t.setRequestHeader("X-HTTP-Method-Override", s);
                if (h)return h.apply(this, arguments)
            }
        }
        if (a.type !== "GET" && !n.emulateJSON) {
            a.processData = false
        }
        var o = n.error;
        n.error = function (t, e, i) {
            n.textStatus = e;
            n.errorThrown = i;
            if (o)o.call(n.context, t, e, i)
        };
        var l = n.xhr = e.ajax(i.extend(a, n));
        r.trigger("request", r, l, n);
        return l
    };
    var H = {create: "POST", update: "PUT", patch: "PATCH", "delete": "DELETE", read: "GET"};
    e.ajax = function () {
        return e.$.ajax.apply(e.$, arguments)
    };
    var $ = e.Router = function (t) {
        t || (t = {});
        if (t.routes)this.routes = t.routes;
        this._bindRoutes();
        this.initialize.apply(this, arguments)
    };
    var A = /\((.*?)\)/g;
    var C = /(\(\?)?:\w+/g;
    var R = /\*\w+/g;
    var j = /[\-{}\[\]+?.,\\\^$|#\s]/g;
    i.extend($.prototype, u, {
        initialize: function () {
        }, route: function (t, r, n) {
            if (!i.isRegExp(t))t = this._routeToRegExp(t);
            if (i.isFunction(r)) {
                n = r;
                r = ""
            }
            if (!n)n = this[r];
            var s = this;
            e.history.route(t, function (i) {
                var a = s._extractParameters(t, i);
                if (s.execute(n, a, r) !== false) {
                    s.trigger.apply(s, ["route:" + r].concat(a));
                    s.trigger("route", r, a);
                    e.history.trigger("route", s, r, a)
                }
            });
            return this
        }, execute: function (t, e, i) {
            if (t)t.apply(this, e)
        }, navigate: function (t, i) {
            e.history.navigate(t, i);
            return this
        }, _bindRoutes: function () {
            if (!this.routes)return;
            this.routes = i.result(this, "routes");
            var t, e = i.keys(this.routes);
            while ((t = e.pop()) != null) {
                this.route(t, this.routes[t])
            }
        }, _routeToRegExp: function (t) {
            t = t.replace(j, "\\$&").replace(A, "(?:$1)?").replace(C, function (t, e) {
                return e ? t : "([^/?]+)"
            }).replace(R, "([^?]*?)");
            return new RegExp("^" + t + "(?:\\?([\\s\\S]*))?$")
        }, _extractParameters: function (t, e) {
            var r = t.exec(e).slice(1);
            return i.map(r, function (t, e) {
                if (e === r.length - 1)return t || null;
                return t ? decodeURIComponent(t) : null
            })
        }
    });
    var N = e.History = function () {
        this.handlers = [];
        this.checkUrl = i.bind(this.checkUrl, this);
        if (typeof window !== "undefined") {
            this.location = window.location;
            this.history = window.history
        }
    };
    var M = /^[#\/]|\s+$/g;
    var O = /^\/+|\/+$/g;
    var U = /#.*$/;
    N.started = false;
    i.extend(N.prototype, u, {
        interval: 50, atRoot: function () {
            var t = this.location.pathname.replace(/[^\/]$/, "$&/");
            return t === this.root && !this.getSearch()
        }, matchRoot: function () {
            var t = this.decodeFragment(this.location.pathname);
            var e = t.slice(0, this.root.length - 1) + "/";
            return e === this.root
        }, decodeFragment: function (t) {
            return decodeURI(t.replace(/%25/g, "%2525"))
        }, getSearch: function () {
            var t = this.location.href.replace(/#.*/, "").match(/\?.+/);
            return t ? t[0] : ""
        }, getHash: function (t) {
            var e = (t || this).location.href.match(/#(.*)$/);
            return e ? e[1] : ""
        }, getPath: function () {
            var t = this.decodeFragment(this.location.pathname + this.getSearch()).slice(this.root.length - 1);
            return t.charAt(0) === "/" ? t.slice(1) : t
        }, getFragment: function (t) {
            if (t == null) {
                if (this._usePushState || !this._wantsHashChange) {
                    t = this.getPath()
                } else {
                    t = this.getHash()
                }
            }
            return t.replace(M, "")
        }, start: function (t) {
            if (N.started)throw new Error("Backbone.history has already been started");
            N.started = true;
            this.options = i.extend({root: "/"}, this.options, t);
            this.root = this.options.root;
            this._wantsHashChange = this.options.hashChange !== false;
            this._hasHashChange = "onhashchange" in window && (document.documentMode === void 0 || document.documentMode > 7);
            this._useHashChange = this._wantsHashChange && this._hasHashChange;
            this._wantsPushState = !!this.options.pushState;
            this._hasPushState = !!(this.history && this.history.pushState);
            this._usePushState = this._wantsPushState && this._hasPushState;
            this.fragment = this.getFragment();
            this.root = ("/" + this.root + "/").replace(O, "/");
            if (this._wantsHashChange && this._wantsPushState) {
                if (!this._hasPushState && !this.atRoot()) {
                    var e = this.root.slice(0, -1) || "/";
                    this.location.replace(e + "#" + this.getPath());
                    return true
                } else if (this._hasPushState && this.atRoot()) {
                    this.navigate(this.getHash(), {replace: true})
                }
            }
            if (!this._hasHashChange && this._wantsHashChange && !this._usePushState) {
                this.iframe = document.createElement("iframe");
                this.iframe.src = "javascript:0";
                this.iframe.style.display = "none";
                this.iframe.tabIndex = -1;
                var r = document.body;
                var n = r.insertBefore(this.iframe, r.firstChild).contentWindow;
                n.document.open();
                n.document.close();
                n.location.hash = "#" + this.fragment
            }
            var s = window.addEventListener || function (t, e) {
                    return attachEvent("on" + t, e)
                };
            if (this._usePushState) {
                s("popstate", this.checkUrl, false)
            } else if (this._useHashChange && !this.iframe) {
                s("hashchange", this.checkUrl, false)
            } else if (this._wantsHashChange) {
                this._checkUrlInterval = setInterval(this.checkUrl, this.interval)
            }
            if (!this.options.silent)return this.loadUrl()
        }, stop: function () {
            var t = window.removeEventListener || function (t, e) {
                    return detachEvent("on" + t, e)
                };
            if (this._usePushState) {
                t("popstate", this.checkUrl, false)
            } else if (this._useHashChange && !this.iframe) {
                t("hashchange", this.checkUrl, false)
            }
            if (this.iframe) {
                document.body.removeChild(this.iframe);
                this.iframe = null
            }
            if (this._checkUrlInterval)clearInterval(this._checkUrlInterval);
            N.started = false
        }, route: function (t, e) {
            this.handlers.unshift({route: t, callback: e})
        }, checkUrl: function (t) {
            var e = this.getFragment();
            if (e === this.fragment && this.iframe) {
                e = this.getHash(this.iframe.contentWindow)
            }
            if (e === this.fragment)return false;
            if (this.iframe)this.navigate(e);
            this.loadUrl()
        }, loadUrl: function (t) {
            if (!this.matchRoot())return false;
            t = this.fragment = this.getFragment(t);
            return i.some(this.handlers, function (e) {
                if (e.route.test(t)) {
                    e.callback(t);
                    return true
                }
            })
        }, navigate: function (t, e) {
            if (!N.started)return false;
            if (!e || e === true)e = {trigger: !!e};
            t = this.getFragment(t || "");
            var i = this.root;
            if (t === "" || t.charAt(0) === "?") {
                i = i.slice(0, -1) || "/"
            }
            var r = i + t;
            t = this.decodeFragment(t.replace(U, ""));
            if (this.fragment === t)return;
            this.fragment = t;
            if (this._usePushState) {
                this.history[e.replace ? "replaceState" : "pushState"]({}, document.title, r)
            } else if (this._wantsHashChange) {
                this._updateHash(this.location, t, e.replace);
                if (this.iframe && t !== this.getHash(this.iframe.contentWindow)) {
                    var n = this.iframe.contentWindow;
                    if (!e.replace) {
                        n.document.open();
                        n.document.close()
                    }
                    this._updateHash(n.location, t, e.replace)
                }
            } else {
                return this.location.assign(r)
            }
            if (e.trigger)return this.loadUrl(t)
        }, _updateHash: function (t, e, i) {
            if (i) {
                var r = t.href.replace(/(javascript:|#).*$/, "");
                t.replace(r + "#" + e)
            } else {
                t.hash = "#" + e
            }
        }
    });
    e.history = new N;
    var q = function (t, e) {
        var r = this;
        var n;
        if (t && i.has(t, "constructor")) {
            n = t.constructor
        } else {
            n = function () {
                return r.apply(this, arguments)
            }
        }
        i.extend(n, r, e);
        n.prototype = i.create(r.prototype, t);
        n.prototype.constructor = n;
        n.__super__ = r.prototype;
        return n
    };
    y.extend = x.extend = $.extend = k.extend = N.extend = q;
    var F = function () {
        throw new Error('A "url" property or function must be specified')
    };
    var B = function (t, e) {
        var i = e.error;
        e.error = function (r) {
            if (i)i.call(e.context, t, r, e);
            t.trigger("error", t, r, e)
        }
    };
    return e
});
//# sourceMappingURL=backbone-min.map